import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import pickle
import time
import csv
import os
from scipy.optimize import least_squares
from scipy.ndimage import median_filter
from itertools import combinations_with_replacement
from astropy.io import fits
from scipy.signal import fftconvolve

from scipy.interpolate import CubicSpline
from scipy.special import eval_legendre
import gc

from matplotlib.backends.backend_pdf import PdfPages
from multiprocessing import Process, Queue
from concurrent.futures import ProcessPoolExecutor, as_completed
import psutil
from collections import defaultdict

import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.offline as pyo

from spectral_synthesis_functions import generate_with_korg
from spectral_synthesis_functions import generate_full_korgspectra

# import juliapkg
# from juliacall import Main as jl
# jl.seval("using Korg"); Korg=jl.Korg





# def generate_with_korg(velocity, wl_wind=None, queue=None, temp=5770, logg=4.438, R=110000, window_size=4, continuum=False, fakedata=False):
#     '''
#     generating stellar spectra with given temperature and logg
#     velocity: array of velocity associated with each layer
#     temp: effetive temperature
#     logg: log g of the star.
#     R: Resolution of the spectra that is required.
#     window_size: how far out to extend the convolution kernel in units of the LSF width (σ, not HWHM)
#     '''
#     if wl_wind is None:
#         wlmin = 4000
#         wlmax = 9000
#     else:
#         wlmin, wlmax = wl_wind
#     # print("velocity array", velocity)
#     # print("But trying without velocity array now")
#     lines = Korg.get_VALD_solar_linelist()
#     # print("Called linelist")
#     A_X = Korg.format_A_X(0)

#     file_path = 'model_atmosphere_{}.mod'.format(temp)
#     atm = Korg.interpolate_marcs(temp, logg, A_X)
#     sol = Korg.synthesize(atm, lines, A_X, wlmin, wlmax,
#                           mu_values=100,
#                           vmic=0.78,
#                           verbose=False,
#                           I_scheme="linear",
#                           velocity_profile=velocity)#+0.08)#, velocity_profile=velocity)a
#     flux = sol.flux
#     cont = sol.cntm
#     wavelengths = sol.wavelengths
#     if not continuum:
#         conv_LSF = Korg.apply_LSF(flux, wavelengths, R, window_size=window_size)
#         conv_flux = np.array(conv_LSF)
#         cont = np.array(cont)
#         wavelengths = np.array(wavelengths)
#         rbflux = pyasl.rotBroad(wavelengths, conv_flux, epsilon=0.6, vsini=1.84)
#         if fakedata:
#             korg_data = {'Flux':rbflux, 'Wl':wavelengths, 'cont':cont}
#         else:
#             korg_data = {'Flux':rbflux/cont, 'Wl':wavelengths}
#         # print("Korg_data", korg_data)
#         del sol
#         del conv_LSF
#         del conv_flux
#         del wavelengths
#         del flux
#         del cont
#         del rbflux
#         return korg_data
#     else:
#         del sol
#         del flux
#         return {'cont':cont, 'Wl':wavelengths}


# def generate_full_korgspectra(velocity, wlwindow=(3700, 9000)):
#     window = 100
#     wl_regions = np.arange(wlwindow[0], wlwindow[1], window)
#     full_flux = np.array([])
#     full_wl = np.array([])
#     for n, wl in enumerate(wl_regions[:-1]):
#         print(wl, wl_regions[n+1])
#         spectra = generate_with_korg(velocity=velocity, wl_wind=(wl-2, wl_regions[n+1]+2))
#         flux = spectra['Flux'][10:-10]
#         wl = spectra['Wl'][10:-10]
#         full_flux = np.concatenate((full_flux, flux))
#         full_wl = np.concatenate((full_wl, wl))
#     # Making the wavelength array into strictly increasing function
#     wl_dict = defaultdict(list)
#     for wl_i, flux_i in zip(full_wl, full_flux):
#         wl_dict[wl_i].append(flux_i)
#     wl_unique = np.array(sorted(wl_dict.keys()))
#     flux_avg = np.array([np.mean(wl_dict[wl_i]) for wl_i in wl_unique])
#     korg_spectra = {'Flux':flux_avg,
#                     'Wl': wl_unique}
#     return korg_spectra
    


def shifting_korg_flux(wavelength, flux, velocity):
    c = 299792.458
    # print('Shifting for ', velocity)
    shifted_wl = wavelength * (velocity/c + 1)
    shifted_flux = CubicSpline(shifted_wl, flux)(wavelength)
    return shifted_flux
    

def shifted_legendre(n, x):
    """
    Compute the nth-degree Shifted Legendre Polynomial at points x in [0, 1].

    Parameters:
        n (int): Degree of the polynomial.
        x (array_like): Points at which to evaluate the polynomial (in [0, 1]).

    Returns:
        array_like: Values of the shifted Legendre polynomial.
    """
    # Transform x from [0, 1] to [-1, 1] for standard Legendre polynomials
    x_transformed = 2 * x - 1
    return eval_legendre(n, x_transformed)


def generate_profile(params, x):
    vel_profile = 0
    # print("Generate_profile", params)
    for n, p in enumerate(params[::-1]):
        # print('Deg', n, p)
        poly_deg = shifted_legendre(n, x)
        vel_profile += poly_deg * p
    return vel_profile
        

def residue_velocity_profile(params, neid_data, linelist, scale_factor=None,falling_params=None,
                             parameter_set=np.array(['r','r','r','r', 'f','f']),
                             stellar_params=None, n_layers=56, selected_orders=None, timer=None,
                             model='bilane',
                             plot_fname='Vel_profile', result_dict='.',
                             korg_data=None,
                             plot_lines=False,
                             fitting_line=False,
                             ratio_dict=None,
                             save_interactive_plot=False,
                             wlwinds=(3700,9000)):
    '''
    Function to find the velocity profile of the raising lane
    params: The model parameters.
    neid_data: Dictionary. {"Flux":ndarray, "Wave":ndarray, "Err", ndarray}
    linelist: list of selected lines.
    scale_factor: If the model is to find scale factor, keep this to None. Otherwise, pass scale factor.
    falling_params: If the falling parameters is already calculated, pass it to here. Otherwise, keep None.
    parameter_set: 'r' means the parameter at this position in the parameter array is for raising lane. 'f' means it is for falling lane.
    Size of this array should be same as size of params.
    stellar_params: Stellar parameters. None will use the parameter for sun.
    n_layer: number of atmospheric layer.
    selected_orders: NEID orders used for the analysis.
    timer: Parameter used to calculate the time passed.
    plot_fname: Filename of plot.
    result_dict: Directory to save the results.
    korg_data: Spectra generated with Korg. If not given, it will be generated in this function.
    fitting_line: Bool. If true, it will fit a gaussian with the line to find the oprtion of the line to select.
    ratio_dict: Dictionary. Ratio between raising and falling lanes. This is to compensate the difference in temperature between them.
    wlwinds: Wavelength window.
    '''
    print("Params {}".format(params))
    penalty_fact = 0
    penalty_fact_derivative = 0
    if stellar_params is not None:
        temp, logg = stellar_params
    if selected_orders is None:
        selected_orders = list(neid_data["Flux"].keys()) # Getting the orders.
    raising_params = None
    if scale_factor is None: # If the scale factor is None, the velocity profile is 0th order by default. Then this function is to calculate the scale_factor
        scale_factor = params[-1]
        raising_params = np.array([params[0]])
        falling_params = np.array([params[1]])
    if falling_params is None:
        raise_mask = parameter_set == 'r'
        fall_mask = parameter_set == 'f'
        raising_params = params[raise_mask] # np.array([params[0], params[1]])
        falling_params = params[fall_mask] #np.array([params[2], params[3]])
    if raising_params is None:
        raising_params = params
        falling_params = falling_params

    # print("Raising params", raising_params)
    # print("Falling params", falling_params)
    # print("scale_factor", scale_factor)
    if korg_data is None: # If pre-defined Korg data is not given, a synthetic data will be generated according to the given velocity profile.
        x = np.linspace(0, 1, n_layers)
        vel_raise = generate_profile(raising_params, x) # np.poly1d(raising_params)(x)  # Velocity profile of raising lane
        if model=='bilane':
            vel_fall = generate_profile(falling_params, x) # np.poly1d(falling_params)(x) # Velocity profile of falling lane
            # Calculating the penalty term for the profile
            vraise_mask = vel_raise > 0
            vfall_mask = vel_fall < 0
            
            vraise_fact = np.sum(vel_raise[vraise_mask])
            vfall_fact = np.sum(vel_fall[vfall_mask])

            # Derivative of the velocity profile
            vraise_der = np.gradient(vel_raise) / np.gradient(x)
            vfall_der = np.gradient(vel_fall) / np.gradient(x)

            # Calculating the penalty term for the derivative of the profile
            vraise_der_mask = vraise_der > 0
            vfall_der_mask = vfall_der < 0
            
            vraise_der_fact = np.sum(np.abs(vraise_der[vraise_der_mask]))
            vfall_der_fact = np.sum(np.abs(vfall_der[vfall_der_mask]))
            
            penalty_fact = abs(vraise_fact) + abs(vfall_fact)
            
            penalty_fact_derivative = abs(vraise_der_fact) + abs(vfall_der_fact)
        else:
            vel_fall = 0

        if plot_lines:
            plt.figure()
            plt.plot(x, vel_raise, 'o-', color='blue')
            if model=='bilane':
                plt.plot(x, vel_fall, 'o-', color='red')
            plt.xlabel("Layer parameter")
            plt.ylabel("Velocity (km/s)")
            plt.savefig(result_dict+"/"+"Velocity_profile_o{}.pdf".format(len(raising_params)-1))
    else:
        # If the pre-defined Korg spectra is given. Preferred to apply on one parameter to save time.
        # This is only to do the fitting for order 0
        korg_flux = korg_data['Flux']
        korg_wl = korg_data['Wl']
        raising_flux = shifting_korg_flux(korg_wl, korg_flux, params[0])
        # falling_lane = shifting_korg_flux(korg_wl, korg_flux, params[1])

    # synt_flux = raising_flux * (1-scale_factor) + falling_lane*scale_factor
    residue_list = np.array([]) # Initilizing the residue array
    centroids = list(linelist.keys()) # List of centroids of the line
    # print("Plot_lines", plot_lines)
    if plot_lines:
        pdf = PdfPages(result_dict+"/"+plot_fname+"_o{}.pdf".format(len(raising_params)-1))
        # fig, axs = plt.subplots(5, 3, figsize=(16, 16))
    # korg_data_raise = generate_full_korgspectra(vel_raise)
    if model == 'bilane': # If the model is bilane, generate the spectra for falling lane
        korg_data_fall = generate_full_korgspectra(vel_fall)
    
    for order in selected_orders:
        # print("Order", order)
        if isinstance(neid_data, str):
            from utils import call_neid_data
            neid_wls, neid_flux, neid_err = call_neid_data(173 - order, neid_data) # If the NEID data is not given.
        else:
            # Extracting the flux, wavelength and error
            neid_flux = neid_data["Flux"][order] 
            neid_wls = neid_data["Wave"][order]
            neid_err = neid_data["Err"][order]
        # generating Korg spectra

        for n, line in enumerate(centroids):
            wl_mask = (neid_wls > linelist[line][0] ) & (neid_wls < linelist[line][1]) & (~np.isnan(neid_wls)) & (~np.isnan(neid_flux)) & (~np.isnan(neid_err)) & (neid_wls >= float(wlwinds[0])) & (neid_wls <= float(wlwinds[1]))
            # print("Check mask", np.sum(wl_mask), neid_wls, neid_flux)
            if np.sum(wl_mask) > 0:
                line_wl = neid_wls[wl_mask]


                line_neid = neid_flux[wl_mask]
                line_err = neid_err[wl_mask]

                line_level = np.percentile(line_neid, 90)

                norm_neid = line_neid # / line_level
                norm_err = line_err # / line_level
                
                # Generating Korg spectra
                if korg_data is None:
                    diff = 5
                    wlmin = int(np.nanmin(line_wl))-diff
                    wlmax = int(np.nanmax(line_wl))+diff
                    # print("Order", order, "Wl window", wlmin, wlmax)
                    # print("vraise_fact:", vraise_fact, vfall_fact)
                    # print(vel_raise)
                    korg_data_raise = generate_with_korg(vel_raise, wl_wind=(wlmin, wlmax))
                    raising_flux = korg_data_raise['Flux']
                    korg_wl = korg_data_raise['Wl']
                    # print(vel_fall)
                    if model=='bilane':
                        # korg_data_fall = generate_with_korg(vel_fall, wl_wind=(wlmin, wlmax))
                        falling_lane = korg_data_fall['Flux']
                    else:
                        falling_lane = 0

                # filtering Korg spectra
                # scaling_the_flux. Useless for entire spectra which continuum fitting was already done.
                if ratio_dict is not None and model=='bilane': # The ratio of continuums of two lanes.
                    ratio_wl = ratio_dict['Wl']
                    ratio = ratio_dict['ratio']
                    ratio_window = CubicSpline(ratio_wl, ratio)(korg_wl)
                    falling_lane = falling_lane / ratio_window
                # print("sizes", np.size(raising_flux), np.size(falling_lane))
                synt_flux = raising_flux # + ((1-scale_factor)/(1+scale_factor)) * falling_lane # The synthetic spectra
                # print(synt_flux, np.sum(np.isnan(synt_flux)))
                # line_korg = CubicSpline(korg_wl, synt_flux)(line_wl)
                # korg_level = np.percentile(line_korg, 90)
                norm_line_korg = line_korg # / korg_level
                
                # Fitting line with a gaussian to reducethe window
                residue = (norm_neid - norm_line_korg)/norm_err
                # print("Fitting line", fitting_line)
                if fitting_line: # If the fitting is for single line, fit the line with a gaussian to isolate the line from other regions. Not needed for entire spectrum.
                    initial_guess = [-0.3, line, 0.3, 1]
                    result = least_squares(residuals_gaussian, initial_guess, args=(line_wl, norm_neid),
                                           verbose=0)
                    popt = result.x
                    A, mu, sigma, C = popt
                    mult = 2
                    fwhm = 2.355*np.abs(sigma)
                    infremum = line - mult*fwhm
                    supremum = line + mult*fwhm
                    sel_mask = (line_wl >= infremum) & (line_wl <= supremum)
                    
                    residue = residue[sel_mask]
                # print(line, "line_wl", line_wl)
                if plot_lines:
                    plt.figure(figsize=(16,8))
                    plt.plot(line_wl, norm_neid, label="NEID {}".format(order+52))
                    plt.plot(line_wl, norm_line_korg, label="Korg")
                    plt.plot(line_wl, CubicSpline(korg_wl, raising_flux/korg_level)(line_wl), '--', color='blue', label='Raising')
                    # plt.plot(line_wl, CubicSpline(korg_wl, ((1-scale_factor)/(1+scale_factor)) * falling_lane/korg_level)(line_wl), '--', color='red', label='Falling')
                    plt.tick_params(axis='both', labelsize=18)
                    plt.xlabel("Wavelength $\AA$", fontsize=18)
                    plt.ylabel("Flux", fontsize=18)
                    plt.tight_layout()
                    
                    # plt.plot(line_wl[sel_mask], norm_neid[sel_mask], 'o-',color='k', label='Selected portion', alpha=0.4)
                    plt.legend()
                    # plt.title("{} \n raising coeffs {} \n falling coeffs {} \n scale factor {}".format(line, raising_params, falling_params, scale_factor))
                    # plt.savefig(result_dict +"/test_spectra_{}_{}.pdf".format(np.nanmin(line_wl), np.nanmax(line_wl)))
                    pdf.savefig()
                    plt.close()
                # for res in residue:
                #     residue_list.append(res)
                if save_interactive_plot:
                    from utils import plot_plotly
                    plotlyfig = make_subplots(
                        rows=2, cols=1, shared_xaxes=True,
                        vertical_spacing=0.02)
                    plot_plotly(plotlyfig, line_wl, norm_neid, 1, 1, 'red', 'NEID')
                    plot_plotly(plotlyfig, line_wl, norm_line_korg, 1, 1, 'green', 'Korg')
                    plot_plotly(plotlyfig, line_wl, residue, 2, 1, 'black', 'Residue')
                    spectra_dir = os.path.join(result_dict, 'Spectra')
                    if not os.path.exists(spectra_dir):
                        os.makedirs(spectra_dir)
                    pyo.plot(plotlyfig, filename=spectra_dir+"/Fitted_spectra_order{}.html".format(order))# )
                residue_list = np.concatenate((residue_list, residue))
    # residue_list.append(penalty_fact*10)
    # residue_list.append(penalty_fact_derivative*10)
    residue_list = np.concatenate((residue_list, np.array([penalty_fact*10, penalty_fact_derivative*10])))
    print("Penalty_added: {}".format(penalty_fact*10))
    print("Derivative Penalty added: {}".format(penalty_fact_derivative*10))
    residue_list = np.array(residue_list)
    if plot_lines:
        # fig.suptitle("raising coeffs {} \n falling coeffs {} \n scale factor {}".format(raising_params, falling_params, scale_factor))
        # plt.savefig(result_dict+"/"+plot_fname+"_o{}.pdf".format(len(raising_params)-1))
        # plt.close()
        pdf.close()
    if timer is not None:
        current = time.time()
        time_passed = current - timer
        print(f"Time passed (s):{time_passed}")
    # print("Residue in function", np.sum(residue_list**2))
    return residue_list


def gaussian(x, A, mu, sigma, C):
    return A * np.exp(-0.5 * ((x - mu) / sigma) ** 2) + C

# Residual function for least_squares fitting
def residuals_gaussian(params, x, y):
    return gaussian(x, *params) - y



def calculate_parameter_errors(least_squares_result):
    """
    Calculate parameter standard errors from least_squares optimization results.
    
    Args:
        least_squares_result: Result object from scipy.optimize.least_squares
        
    Returns:
        tuple: (parameter_errors, covariance_matrix)
            - parameter_errors: array of standard errors for each parameter
            - covariance_matrix: estimated covariance matrix
            
    Note: Assumes Gaussian errors and uses linear approximation for uncertainty estimation.
    """
    # Extract components from optimization result
    J = least_squares_result.jac  # Jacobian matrix
    residuals = least_squares_result.fun  # Residual vector
    m, n = J.shape  # m = data points, n = parameters
    
    if m <= n:
        raise ValueError("More parameters than data points - cannot compute errors")
    
    # Calculate residual variance (sigma^2)
    residuals_sum_sq = np.sum(residuals**2)
    sigma_sq = residuals_sum_sq / (m - n)
    
    # Compute covariance matrix using pseudoinverse for numerical stability
    try:
        cov_matrix = sigma_sq * np.linalg.pinv(J.T @ J)
    except np.linalg.LinAlgError:
        cov_matrix = sigma_sq * np.linalg.inv(J.T @ J)
    
    # Calculate standard errors from covariance matrix diagonal
    param_errors = np.sqrt(np.diag(cov_matrix))
    
    return param_errors, cov_matrix
