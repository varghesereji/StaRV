import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import least_squares
import time
import os
from collections import defaultdict
import shutil
import csv

from utils import calling_linelist
# from utils import call_neid_data, call_neiddata_full
from utils import call_neiddata_full
from utils import generate_fakedata
from utils import save_dict_to_pickle

from functools import *

import multiprocessing
import pickle

# from model_functions import residue_scale_factor
from model_functions import residue_velocity_profile
from model_functions import generate_with_korg
from model_functions import generate_profile
from model_functions import shifting_korg_flux
from model_functions import calculate_parameter_errors
from model_functions import generate_full_korgspectra

from scipy.interpolate import CubicSpline
import juliapkg
from juliacall import Main as jl
jl.seval("using Korg"); Korg=jl.Korg

import sys
import argparse
import logging





def velprofile_fit_function(neid_filename, wlwinds=(4000, 9000), save_generated_syntspectra=False, dead_velocity=-0.1,
                            snr=500, purpose='debug'):
    if neid_filename == 'all':
        basename = 'all'
    elif neid_filename == 'Korg':
        basename = 'Korg'
    else:
        basename = os.path.splitext(neid_filename)[0]
    purpose=None
    # dead_velocity = -0.1
    # snr = 500
    # resultdict = "Result_allgrayline_korgcont_constinterp/Result_directory_witherrcov_" + basename
    # resultdict = os.path.join("Result_algorithm_30epoches", "Result_directory_witherrcov_" + basename)
    # resultdict = os.path.join("Result_zeroth_onelineremoved3", "Result_dir_" + basename + "_{}-{}".format(wlwinds[0], wlwinds[1]))
    srcdir = "/home/varghese/Desktop/Stellar_activity_mitigation"
    # master_resdir = "16_onelane_include"
    master_resdir = "17_fake_data"
    # master_resdir = "19_fullneidrange"
    
    # master_subdir = "Result_zeroth_srctest"
    # master_subdir = "Result_fakedata_smallrange"
    # master_subdir = "Result_simpledopplershift"
    master_subdir = 'Result_LowSNRtest'
    if purpose=='debug':
        master_subdir += '_debug'

    resultsubdir_prefix = 'Result_dir_actualway_'
    if basename == 'Korg':
        resultsubdir_prefix += "{}_snr{}_".format(round(dead_velocity, 7), snr)
    resultdict = os.path.join(srcdir, master_resdir, master_subdir, resultsubdir_prefix + basename + "_{}-{}".format(wlwinds[0], wlwinds[1]))
        # print(fullpath)
    if not os.path.exists(resultdict):
        os.makedirs(resultdict)
        print(resultdict, "Directory created successfully!")
    else:
        print(resultdict, "Directory already exists!")

    logging.basicConfig(filename=resultdict+"/least_squares.log", level=logging.INFO, format="%(asctime)s - %(message)s")

    class StreamToLogger:
        """Redirects stdout/stderr to logging"""
        def __init__(self, logger, level):
            self.logger = logger
            self.level = level
            self.buffer = ""

        def write(self, message):
            if message.strip():  # Avoid empty lines
                self.logger.log(self.level, message.strip())

        def flush(self):
            pass  # No need to flush for logging

    # Redirect stdout and stderr
    sys.stdout = StreamToLogger(logging.getLogger(), logging.INFO)
    sys.stderr = StreamToLogger(logging.getLogger(), logging.ERROR)

    
    result_filename = os.path.join(resultdict, "fitted_params.pkl")
    if os.path.isfile(result_filename):
        print("The results already exists. If you want to make new result, change the name of the directory")
        return
    print("This trial is running on instantaneous frames. In this trial, I am keeping ftol and xtol=None. This is to check why the gradient is so large at the converged point. The dead velocity is 0.")
    # maindir = '/home/varghese/Desktop/Stellar_activity_mitigation/Full_data'
    # maindir = '/home/varghese/Desktop/Stellar_activity_mitigation/NEID_data_onecycle'
    maindir = '/data/varghese/NEID_data/NEID_data_onecycle'
    korg_data_name = os.path.join("data", "Ref_spectra_korg.pkl")
    if os.path.isfile(korg_data_name):
        print("The reference Korg data already exists. Calling that one")
        with open(korg_data_name, 'rb') as korgspec:
            korg_data_ref = pickle.load(korgspec)
    else:
        print("The reference Korg data does not exist. Generating one.")
        korg_data_ref =generate_full_korgspectra(velocity=False)
        save_dict_to_pickle(korg_data_ref, korg_data_name)
        
    print("Resultdict", resultdict)
    shutil.copy("utils.py", resultdict)
    shutil.copy("model_functions.py", resultdict)
    print("Model functions copied sucessfully")
    shutil.copy("Velocity_fitting_function_fakedata.py", resultdict)
    print("This code copied sucessfully")
    
    # korg_filename = "Korg_data_3800_9000.pkl"
    # if os.path.exists(korg_filename):
    #     print("The data already exists.")
    #     with open(korg_filename, 'rb') as korgfile:
    #         korg_data = pickle.load(korgfile)
    # else:
    #     print("Pre-generated data does not exist. Generating now")
        
    #     korg_data = generate_with_korg(np.zeros(56), (3800, 9000), continuum=True)
    #     with open(korg_filename, 'wb') as korgfile:
    #         pickle.dump(korg_data, korgfile)

    cntm_filename = "data/Ratio_3800_9000.pkl"
    if os.path.exists(cntm_filename):
        print("The continuums already exists.")
        with open(cntm_filename, 'rb') as korgfile:
            ratio_pkl = pickle.load(korgfile)
    else:
        print("Pre-generated data does not exist. Generating now")

        cntm1_data = generate_with_korg(np.zeros(56), (3800, 9000), continuum=True)
        cntm1 = cntm1_data['cont']
        cntm2_data = generate_with_korg(np.zeros(56), (3800, 9000), temp=5570, continuum=True)
        cntm2 = cntm2_data['cont']
        wl = cntm2_data['Wl']
        print('Type', type(cntm1))
        ratio = cntm1/cntm2
        ratio_pkl = {'ratio':ratio, 'Wl':wl}

        with open(cntm_filename, 'wb') as korgfile:
            pickle.dump(ratio_pkl, korgfile)

    

    neid_orders = 115
    #km/s. This is the additional velocity adding to neid spectra.
    neid_data_dict = defaultdict(list)
    if neid_filename == 'all':
        files_list = [f for f in os.listdir(maindir) if f.endswith(".fits")]
        # files_list = os.listdir(maindir)
    else:
        files_list = [neid_filename]
    for onefile in files_list:
        if onefile == "Korg":
            reference_file = "neidL2_20220514T172101.fits"
            fullpath = os.path.join(maindir, reference_file)
            neid_data_dict = generate_fakedata([dead_velocity], snr, fullpath, resultdict)
        else:
            fullpath = os.path.join(maindir, onefile)
            neid_data_dict = call_neiddata_full(fullpath, resultdict, refspec=korg_data_ref)
    # print(neid_data_dict)


    # Calling lines
    lines_file_path = '/home/varghese/Desktop/Stellar_activity_mitigation'
    solar_lines_fname ='FullNeidRange.csv' # 'Solar_lines_gray.csv' #'sol_line_window_modified.csv' #  # 'sol_line_window_modified.csv'
    line_dict = calling_linelist(os.path.join(lines_file_path, solar_lines_fname))
    shutil.copy(os.path.join(lines_file_path, solar_lines_fname), resultdict)
    # korg_data = generate_with_korg(np.zeros(56))

    
    # print("simply calling Korg")
    # generate_with_korg(velocity=None)
    print("Start fitting")
    # residue_scale_factor([0,0,0], neid_data_dict, line_dict, korg_data)
    starttime=time.time()

    v_raise0 = -0.6109816 # fitted_params[0]
    scale_factor = 1

    plot_fname = "Fitted_spectra"
    # To do for single lane one parameter
    init_params3 = 0.0
    lower_bounds = -np.inf
    upper_bounds = np.inf

    residue_vel3 = partial(residue_velocity_profile, neid_data=neid_data_dict,
                           linelist=line_dict,
                           scale_factor=scale_factor,
                           falling_params=0,
                           timer=starttime,
                           result_dict=resultdict,
                           plot_fname=plot_fname,
                           ratio_dict=ratio_pkl,
                           model='onelane',
                           selected_orders=None,
                           wlwinds=wlwinds,
                           korg_data=korg_data_ref)
    result3 = least_squares(residue_vel3, init_params3,
                            bounds=(lower_bounds, upper_bounds),
                            x_scale='jac',
                            verbose=2,
                            ftol=None,
                            loss='linear',
                            max_nfev=1000)

    print(result3)
    fitted_params3 = result3.x
    # fitted_params3 = [4.93100795e-05, -7.32842107e-05, -1.13824891e+00, 1.32546308e+00, 1.68787459e+00]
    print("Fitted_params for third order", result3.x)
    residue_vel3(params=fitted_params3, plot_lines=True, save_interactive_plot=False)

    errorvals, cov_matrix = calculate_parameter_errors(result3)
    resultdictionary = {'params':fitted_params3,
                       'params_err': errorvals,
                       'cov_matr': cov_matrix}
    
    save_dict_to_pickle(resultdictionary, result_filename)
    save_dict_to_pickle(result3, os.path.join(resultdict, "least_squares_op.pkl"))
    if save_generated_syntspectra:
        x = np.linspace(0, 1, 56)
        vel_raise = generate_profile(fitted_params3, x)
        # vel_fall = generate_profile(fitted_params3[-2:], x)
        print(vel_raise)
        raising_spectra = generate_with_korg(vel_raise)
        # falling_spectra = generate_with_korg(vel_fall)
        generated_spectra = {"Raise":raising_spectra}
        # "Fall":falling_spectra}
        result_specname = os.path.join(resultdict, "Generated_spectra.pkl")
        save_dict_to_pickle(generated_spectra, result_specname)

    print("Results saved in", resultdict)


# print("Arguements:", sys.argv)


parser = argparse.ArgumentParser(description="Run velprofile fitting.")

# Required positional argument
parser.add_argument('fname', type=str, help='Input file name')

# --WL takes 2 values
parser.add_argument('--WL', type=float, nargs=2, metavar=('wl_wind1', 'wl_wind2'), default=[3700, 9000], help='Wavelength window (start end)')

# --SNR is optional here, but we will enforce it manually later if fname=="Korg"
parser.add_argument('--SNR', type=float, help='Signal-to-noise ratio (only needed if fname is Korg)')

# --dead_vel
parser.add_argument('--dead_vel', type=float, default=-0.1, help='Dead velocity')

# Parse args
args = parser.parse_args()

# Unpack WL window
wl_wind1, wl_wind2 = args.WL

# Check if SNR is needed
if args.fname == "Korg" and args.SNR is None:
    print("Error: --SNR must be provided when fname is 'Korg'.")
    sys.exit(1)

# Either use given SNR or a dummy value if not provided (only for non-Korg cases)
snr_value = args.SNR if args.SNR is not None else 500  # You can also choose not to pass it at all if not needed

# Print info
print("Doing for:", args.fname)
print(f"Wavelength window: {wl_wind1} - {wl_wind2}")
print(f"Dead velocity: {args.dead_vel}")
if args.fname == "Korg":
    print(f"SNR: {args.SNR}")

# Call your function
velprofile_fit_function(
    args.fname,
    wlwinds=(wl_wind1, wl_wind2),
    dead_velocity=args.dead_vel,
    snr=snr_value  # Only needed for Korg, but passing anyway
)


'''
if len(sys.argv) > 1:
    args = sys.argv[1:]
    fname = args[0] # sys.argv[1]
    if len(args) > 1:
        wl_wind1 = args[1]
        wl_wind2 = args[2]
        snr = float(args[3])
        dead_vel = float(args[4])
    else:
        wl_wind1 = 4000
        wl_wind2 = 9000
        snr = 500
        dead_vel = -0.1
    # print(fname)
    print("Doing for:", fname)
    velprofile_fit_function(fname, wlwinds=(wl_wind1, wl_wind2), dead_velocity=dead_vel, snr=snr)
    # for i, arg in enumerate(sys.argv[1:], start=1):
    #     print(f'Argument {i}: {arg}')
else:
    print("No arguments were provided.")
'''
print('\a')




